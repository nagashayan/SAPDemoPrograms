/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.ejb.sap;

import java.util.List;
import javax.ejb.Remote;

/**
 *
 * @author I860873
 */
@Remote
public interface LibrarySessionBeanRemote {
    
    void addBook(String bookName);
    
    List getBooks();
    
}
