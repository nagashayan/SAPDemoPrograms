/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import javax.ejb.Stateless;

/**
 *
 * @author nb
 */
@Stateless
public class MySession implements MySessionRemote {

    @Override
    public String getResult() {
        return "This is My Session Bean";
    }

   
    
}
